import os
import numpy as np

from train import Autoencoder_Model

base_dir = os.path.abspath("diplom_autoencoder")
path_searchbarrier = os.path.join(base_dir, "data", "processed", "search_barrier")

# --------------------------------------------------------------------


def check_choise_result_barrier():
    tr = Autoencoder_Model()

    tr.choise_result_barrier(path_imp_data = path_searchbarrier)

# --------------------------------------------------------------------


def check_get_mse():
    tr = Autoencoder_Model()
    Control_barrier_Normal = tr.get_np_arr_from_csv(os.path.join(path_searchbarrier, "Control_barrier_Normal.csv"))
    Control_barrier_Anomal = tr.get_np_arr_from_csv(os.path.join(path_searchbarrier, "Control_barrier_Anomal.csv"))

    res = tr.get_mse(Control_barrier_Normal, Control_barrier_Anomal)

    # print(f"Control_barrier_Normal = {Control_barrier_Normal}")
    # print(f"\nControl_barrier_Anomal = {Control_barrier_Anomal}")
    print(f"res = {res}")

check_get_mse()

# --------------------------------------------------------------------